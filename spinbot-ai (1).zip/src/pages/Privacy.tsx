import React from 'react';
import { motion } from 'motion/react';
import { Shield, Lock, Eye, FileText } from 'lucide-react';

export default function Privacy() {
  return (
    <div className="min-h-screen bg-[#F9FAFB] py-12 px-4">
      <div className="max-w-3xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 md:p-12 rounded-3xl border border-zinc-200 shadow-sm"
        >
          <div className="flex items-center gap-3 mb-8 text-emerald-600">
            <Shield className="w-8 h-8" />
            <h1 className="text-3xl font-bold text-zinc-900">Privacy Policy</h1>
          </div>

          <div className="prose prose-zinc max-w-none space-y-6 text-zinc-600 leading-relaxed">
            <section>
              <h2 className="text-xl font-bold text-zinc-900 flex items-center gap-2 mb-3">
                <Eye className="w-5 h-5 text-emerald-500" /> 1. Information We Collect
              </h2>
              <p>
                SpinBot AI is designed with privacy in mind. We do not store the text you input for paraphrasing on our servers beyond the duration of the processing request. Your text is processed in real-time using the Google Gemini API.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-zinc-900 flex items-center gap-2 mb-3">
                <Lock className="w-5 h-5 text-emerald-500" /> 2. Data Usage
              </h2>
              <p>
                The information you provide is used solely to provide the paraphrasing service. We do not sell, trade, or otherwise transfer your personally identifiable information to outside parties.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-zinc-900 flex items-center gap-2 mb-3">
                <FileText className="w-5 h-5 text-emerald-500" /> 3. Local Storage
              </h2>
              <p>
                We use your browser's local storage to save your "Recent Activity" history. This data stays entirely on your device and is never uploaded to our servers. You can clear this history at any time from the History sidebar.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-zinc-900 mb-3">4. Third-Party Services</h2>
              <p>
                Our service utilizes the Google Gemini API. By using SpinBot AI, you are also subject to Google's Privacy Policy regarding the data sent for processing.
              </p>
            </section>

            <div className="pt-8 border-t border-zinc-100 text-sm text-zinc-400">
              Last updated: March 13, 2026
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
