import React from 'react';
import { motion } from 'motion/react';
import { Scale, CheckCircle, AlertTriangle, Info } from 'lucide-react';

export default function Terms() {
  return (
    <div className="min-h-screen bg-[#F9FAFB] py-12 px-4">
      <div className="max-w-3xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 md:p-12 rounded-3xl border border-zinc-200 shadow-sm"
        >
          <div className="flex items-center gap-3 mb-8 text-emerald-600">
            <Scale className="w-8 h-8" />
            <h1 className="text-3xl font-bold text-zinc-900">Terms of Service</h1>
          </div>

          <div className="prose prose-zinc max-w-none space-y-6 text-zinc-600 leading-relaxed">
            <section>
              <h2 className="text-xl font-bold text-zinc-900 flex items-center gap-2 mb-3">
                <CheckCircle className="w-5 h-5 text-emerald-500" /> 1. Acceptance of Terms
              </h2>
              <p>
                By accessing and using SpinBot AI, you accept and agree to be bound by the terms and provision of this agreement.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-zinc-900 flex items-center gap-2 mb-3">
                <Info className="w-5 h-5 text-emerald-500" /> 2. Use License
              </h2>
              <p>
                Permission is granted to use SpinBot AI for personal or commercial text rewriting. You may not use the service for any illegal activities or to generate harmful content.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-zinc-900 flex items-center gap-2 mb-3">
                <AlertTriangle className="w-5 h-5 text-emerald-500" /> 3. Disclaimer
              </h2>
              <p>
                The materials on SpinBot AI are provided on an 'as is' basis. SpinBot AI makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-bold text-zinc-900 mb-3">4. Accuracy of Materials</h2>
              <p>
                The AI-generated content may contain errors. We do not guarantee the accuracy, completeness, or usefulness of any information provided by the AI.
              </p>
            </section>

            <div className="pt-8 border-t border-zinc-100 text-sm text-zinc-400">
              Last updated: March 13, 2026
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
