/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import { GoogleGenAI, Type } from "@google/genai";
import { 
  RefreshCw, 
  Copy, 
  Trash2, 
  Sparkles, 
  Check, 
  AlertCircle,
  Type as TypeIcon,
  Maximize2,
  Minimize2,
  Zap,
  BookOpen,
  BarChart3,
  History,
  Lightbulb,
  ArrowRight,
  BrainCircuit,
  Smile,
  ShieldCheck,
  Clock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Import Pages
import Privacy from './pages/Privacy';
import Terms from './pages/Terms';
import Contact from './pages/Contact';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// AI Configuration
// In AI Studio, process.env.GEMINI_API_KEY is used.
// For exported apps (Vercel/Netlify), use import.meta.env.VITE_GEMINI_API_KEY.
const API_KEY = process.env.GEMINI_API_KEY || import.meta.env.VITE_GEMINI_API_KEY;

let ai: GoogleGenAI | null = null;
if (API_KEY && API_KEY !== 'your_api_key_here') {
  ai = new GoogleGenAI({ apiKey: API_KEY });
}

type Mode = 'standard' | 'creative' | 'formal' | 'shorten' | 'expand';

interface ModeOption {
  id: Mode;
  label: string;
  icon: React.ReactNode;
  description: string;
}

const MODES: ModeOption[] = [
  { 
    id: 'standard', 
    label: 'Standard', 
    icon: <Zap className="w-4 h-4" />, 
    description: 'Balanced rewriting for clarity and flow.' 
  },
  { 
    id: 'creative', 
    label: 'Creative', 
    icon: <Sparkles className="w-4 h-4" />, 
    description: 'More imaginative and varied word choices.' 
  },
  { 
    id: 'formal', 
    label: 'Formal', 
    icon: <BookOpen className="w-4 h-4" />, 
    description: 'Professional and academic tone.' 
  },
  { 
    id: 'shorten', 
    label: 'Shorten', 
    icon: <Minimize2 className="w-4 h-4" />, 
    description: 'Concise version while keeping core meaning.' 
  },
  { 
    id: 'expand', 
    label: 'Expand', 
    icon: <Maximize2 className="w-4 h-4" />, 
    description: 'Adds detail and depth to your text.' 
  },
];

interface AIInsights {
  tone: {
    label: string;
    score: number; // 0-100
  }[];
  readability: string;
  keyPoints: string[];
  improvement: string;
}

interface HistoryItem {
  id: string;
  original: string;
  rewritten: string;
  mode: Mode;
  timestamp: number;
}

function Home() {
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const [isSpinning, setIsSpinning] = useState(false);
  const [selectedMode, setSelectedMode] = useState<Mode>('standard');
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [insights, setInsights] = useState<AIInsights | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  // Load history from local storage
  useEffect(() => {
    const saved = localStorage.getItem('spinbot_history');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load history", e);
      }
    }
  }, []);

  // Save history to local storage
  useEffect(() => {
    localStorage.setItem('spinbot_history', JSON.stringify(history.slice(0, 20)));
  }, [history]);

  const handleSpin = useCallback(async () => {
    if (!inputText.trim()) return;

    setIsSpinning(true);
    setError(null);
    setInsights(null);

    try {
      if (!ai) {
        setError("Gemini API Key is missing. Please add VITE_GEMINI_API_KEY to your environment variables.");
        return;
      }

      const modePrompt = {
        standard: "Rewrite the following text to be clearer and more natural while maintaining the original meaning.",
        creative: "Rewrite the following text creatively, using diverse vocabulary and interesting sentence structures.",
        formal: "Rewrite the following text in a formal, professional, and academic tone.",
        shorten: "Rewrite the following text to be as concise as possible without losing the main points.",
        expand: "Rewrite the following text by adding more detail, explanations, and descriptive language."
      }[selectedMode];

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `
          Task 1: ${modePrompt}
          Task 2: Analyze the rewritten text and provide insights in JSON format.
          
          Text to rewrite: ${inputText}
          
          Return your response as a JSON object with two keys:
          - "rewrittenText": The rewritten version of the input.
          - "insights": An object containing:
            - "tone": An array of objects with "label" (e.g., "Professional", "Friendly", "Confident") and "score" (0-100).
            - "readability": A short string describing the reading level (e.g., "Easy", "Advanced").
            - "keyPoints": An array of 2-3 main takeaways from the text.
            - "improvement": A one-sentence explanation of why this version is better.
        `,
        config: {
          temperature: 0.7,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              rewrittenText: { type: Type.STRING },
              insights: {
                type: Type.OBJECT,
                properties: {
                  tone: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        label: { type: Type.STRING },
                        score: { type: Type.NUMBER }
                      }
                    }
                  },
                  readability: { type: Type.STRING },
                  keyPoints: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  },
                  improvement: { type: Type.STRING }
                }
              }
            }
          }
        }
      });

      const data = JSON.parse(response.text || "{}");
      setOutputText(data.rewrittenText || "No response generated.");
      setInsights(data.insights || null);

      const newItem: HistoryItem = {
        id: Math.random().toString(36).substr(2, 9),
        original: inputText,
        rewritten: data.rewrittenText,
        mode: selectedMode,
        timestamp: Date.now()
      };
      setHistory(prev => [newItem, ...prev]);

    } catch (err) {
      console.error("Spin error:", err);
      setError("Failed to rewrite text. Please try again.");
    } finally {
      setIsSpinning(false);
    }
  }, [inputText, selectedMode]);

  const copyToClipboard = () => {
    if (!outputText) return;
    navigator.clipboard.writeText(outputText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const clearInput = () => {
    setInputText('');
    setOutputText('');
    setError(null);
    setInsights(null);
  };

  const wordCount = (text: string) => text.trim() ? text.trim().split(/\s+/).length : 0;
  const charCount = (text: string) => text.length;

  return (
    <>
      <header className="border-b border-zinc-200 bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
              <RefreshCw className="text-white w-5 h-5" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-zinc-900">SpinBot <span className="text-emerald-600">AI</span></h1>
          </Link>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setShowHistory(true)}
              className="p-2 text-zinc-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors relative"
            >
              <History className="w-5 h-5" />
              {history.length > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-emerald-500 rounded-full border-2 border-white" />
              )}
            </button>
            <div className="hidden sm:flex items-center gap-6 text-sm font-medium text-zinc-500">
              <Link to="/contact" className="hover:text-emerald-600 transition-colors">Contact</Link>
              <a href="#" className="hover:text-emerald-600 transition-colors">Pricing</a>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 md:py-12">
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold uppercase tracking-wider mb-4 border border-emerald-100"
          >
            <BrainCircuit className="w-3.5 h-3.5" /> Powered by Gemini AI
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-extrabold text-zinc-900 mb-4 tracking-tight"
          >
            Rewrite with <span className="text-emerald-600">Intelligence</span>
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-zinc-500 text-lg max-w-2xl mx-auto"
          >
            Transform your text instantly using advanced AI. Whether you need to simplify, formalize, or expand, we've got you covered.
          </motion.p>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {MODES.map((mode) => (
            <motion.button
              key={mode.id}
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSelectedMode(mode.id)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200",
                selectedMode === mode.id 
                  ? "bg-emerald-600 text-white shadow-lg shadow-emerald-200 scale-105" 
                  : "bg-white text-zinc-600 border border-zinc-200 hover:border-emerald-300 hover:bg-emerald-50"
              )}
            >
              {mode.icon}
              {mode.label}
            </motion.button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 relative">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col gap-2"
          >
            <div className="flex items-center justify-between px-2">
              <label className="text-xs font-bold uppercase tracking-widest text-zinc-400 flex items-center gap-1.5">
                <TypeIcon className="w-3 h-3" /> Original Text
              </label>
              <span className="text-xs text-zinc-400 font-mono">
                {wordCount(inputText)} words / {charCount(inputText)} chars
              </span>
            </div>
            <div className="relative group">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Paste or type your text here..."
                className="w-full h-[400px] p-6 bg-white border border-zinc-200 rounded-2xl shadow-sm focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all resize-none text-zinc-700 leading-relaxed placeholder:text-zinc-300"
              />
              <div className="absolute bottom-4 right-4 flex gap-2">
                <motion.button 
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={clearInput}
                  disabled={!inputText}
                  className="p-2 text-zinc-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-0"
                  title="Clear all"
                >
                  <Trash2 className="w-5 h-5" />
                </motion.button>
              </div>
            </div>
          </motion.div>

          <div className="lg:hidden flex justify-center py-2">
             <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleSpin}
              disabled={isSpinning || !inputText.trim()}
              className="w-full py-4 bg-emerald-600 text-white rounded-xl font-bold shadow-xl shadow-emerald-200 flex items-center justify-center gap-2 active:scale-95 transition-transform disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSpinning ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5" />}
              {isSpinning ? 'Rewriting...' : 'Rewrite Text'}
            </motion.button>
          </div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col gap-2"
          >
            <div className="flex items-center justify-between px-2">
              <label className="text-xs font-bold uppercase tracking-widest text-zinc-400 flex items-center gap-1.5">
                <Sparkles className="w-3 h-3" /> AI Result
              </label>
              <span className="text-xs text-zinc-400 font-mono">
                {wordCount(outputText)} words
              </span>
            </div>
            <div className="relative">
              <div className={cn(
                "w-full h-[400px] p-6 bg-zinc-50 border border-zinc-200 rounded-2xl shadow-inner overflow-auto text-zinc-700 leading-relaxed",
                isSpinning && "opacity-50"
              )}>
                {isSpinning ? (
                  <div className="h-full flex flex-col items-center justify-center gap-4 text-zinc-400">
                    <div className="flex gap-1">
                      <motion.div animate={{ scale: [1, 1.5, 1] }} transition={{ repeat: Infinity, duration: 1 }} className="w-2 h-2 bg-emerald-400 rounded-full" />
                      <motion.div animate={{ scale: [1, 1.5, 1] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-2 h-2 bg-emerald-400 rounded-full" />
                      <motion.div animate={{ scale: [1, 1.5, 1] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-2 h-2 bg-emerald-400 rounded-full" />
                    </div>
                    <p className="text-sm font-medium italic">Gemini is crafting your text...</p>
                  </div>
                ) : outputText ? (
                  <div className="whitespace-pre-wrap">{outputText}</div>
                ) : (
                  <div className="h-full flex items-center justify-center text-zinc-300 italic">
                    Your rewritten text will appear here.
                  </div>
                )}
              </div>
              
              <AnimatePresence>
                {outputText && !isSpinning && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="absolute bottom-4 right-4 flex gap-2"
                  >
                    <motion.button 
                      whileHover={{ y: -2 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={copyToClipboard}
                      className={cn(
                        "flex items-center gap-2 px-4 py-2 rounded-xl font-bold transition-all duration-200",
                        copied 
                          ? "bg-emerald-100 text-emerald-700 border border-emerald-200" 
                          : "bg-white text-zinc-700 border border-zinc-200 shadow-sm hover:border-emerald-500 hover:text-emerald-600"
                      )}
                    >
                      {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      {copied ? 'Copied!' : 'Copy'}
                    </motion.button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>

          <div className="hidden lg:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
            <motion.button
              whileHover={{ scale: 1.1, rotate: 5 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleSpin}
              disabled={isSpinning || !inputText.trim()}
              className="w-16 h-16 bg-emerald-600 text-white rounded-full shadow-2xl shadow-emerald-300 flex items-center justify-center hover:scale-110 active:scale-95 transition-all disabled:opacity-50 disabled:scale-100 disabled:cursor-not-allowed group"
            >
              {isSpinning ? (
                <RefreshCw className="w-8 h-8 animate-spin" />
              ) : (
                <Zap className="w-8 h-8 group-hover:fill-current" />
              )}
            </motion.button>
          </div>
        </div>

        <AnimatePresence>
          {insights && !isSpinning && (
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 40 }}
              className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6"
            >
              <div className="col-span-1 md:col-span-3">
                <h3 className="text-sm font-bold uppercase tracking-widest text-zinc-400 mb-4 flex items-center gap-2">
                  <BarChart3 className="w-4 h-4" /> AI Insights & Tone Analysis
                </h3>
              </div>
              
              <motion.div 
                whileHover={{ y: -5 }}
                className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm transition-shadow hover:shadow-md"
              >
                <div className="flex items-center gap-2 mb-4 text-emerald-600">
                  <Smile className="w-5 h-5" />
                  <h4 className="font-bold">Tone Breakdown</h4>
                </div>
                <div className="space-y-4">
                  {insights.tone.map((t, idx) => (
                    <div key={idx} className="space-y-1.5">
                      <div className="flex justify-between text-xs font-bold text-zinc-500">
                        <span>{t.label}</span>
                        <span>{t.score}%</span>
                      </div>
                      <div className="h-1.5 w-full bg-zinc-100 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${t.score}%` }}
                          transition={{ delay: 0.2 + idx * 0.1, duration: 0.8 }}
                          className="h-full bg-emerald-500"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>

              <motion.div 
                whileHover={{ y: -5 }}
                className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm transition-shadow hover:shadow-md"
              >
                <div className="flex items-center gap-2 mb-4 text-blue-600">
                  <Lightbulb className="w-5 h-5" />
                  <h4 className="font-bold">Key Takeaways</h4>
                </div>
                <ul className="space-y-3">
                  {insights.keyPoints.map((point, idx) => (
                    <motion.li 
                      key={idx} 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.3 + idx * 0.1 }}
                      className="flex gap-2 text-sm text-zinc-600 leading-relaxed"
                    >
                      <ArrowRight className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                      {point}
                    </motion.li>
                  ))}
                </ul>
              </motion.div>

              <motion.div 
                whileHover={{ y: -5 }}
                className="bg-white p-6 rounded-3xl border border-zinc-200 shadow-sm transition-shadow hover:shadow-md"
              >
                <div className="flex items-center gap-2 mb-4 text-purple-600">
                  <ShieldCheck className="w-5 h-5" />
                  <h4 className="font-bold">Quality Report</h4>
                </div>
                <div className="space-y-4">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400">Readability</span>
                    <p className="text-sm font-bold text-zinc-700 mt-1">{insights.readability}</p>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400">AI Improvement</span>
                    <p className="text-sm text-zinc-600 leading-relaxed mt-1 italic">"{insights.improvement}"</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {error && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="mt-6 p-4 bg-red-50 border border-red-100 rounded-xl flex items-center gap-3 text-red-600 text-sm font-medium"
            >
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              {error}
            </motion.div>
          )}
        </AnimatePresence>

        <motion.section 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-8"
        >
          <motion.div 
            whileHover={{ y: -10 }}
            className="p-8 bg-white rounded-3xl border border-zinc-100 shadow-sm hover:shadow-xl transition-all duration-300"
          >
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-6">
              <Zap className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-zinc-900 mb-3">Lightning Fast</h3>
            <p className="text-zinc-500 leading-relaxed">Powered by Gemini 3 Flash for near-instant paraphrasing without compromising quality.</p>
          </motion.div>
          <motion.div 
            whileHover={{ y: -10 }}
            className="p-8 bg-white rounded-3xl border border-zinc-100 shadow-sm hover:shadow-xl transition-all duration-300"
          >
            <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center mb-6">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-zinc-900 mb-3">Context Aware</h3>
            <p className="text-zinc-500 leading-relaxed">Our AI understands the nuance of your text, ensuring the meaning remains intact while the words change.</p>
          </motion.div>
          <motion.div 
            whileHover={{ y: -10 }}
            className="p-8 bg-white rounded-3xl border border-zinc-100 shadow-sm hover:shadow-xl transition-all duration-300"
          >
            <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mb-6">
              <Check className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-zinc-900 mb-3">Plagiarism Free</h3>
            <p className="text-zinc-500 leading-relaxed">Generate unique content that passes plagiarism checks while maintaining your original voice.</p>
          </motion.div>
        </motion.section>
      </main>

      <AnimatePresence>
        {showHistory && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowHistory(false)}
              className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60]"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-white shadow-2xl z-[70] flex flex-col"
            >
              <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
                <h3 className="text-lg font-bold flex items-center gap-2">
                  <History className="w-5 h-5 text-emerald-600" /> Recent Activity
                </h3>
                <button 
                  onClick={() => setShowHistory(false)}
                  className="p-2 hover:bg-zinc-100 rounded-full transition-colors"
                >
                  <Trash2 className="w-5 h-5 text-zinc-400" />
                </button>
              </div>
              <div className="flex-1 overflow-auto p-6 space-y-6">
                {history.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-zinc-400 gap-4">
                    <Clock className="w-12 h-12 opacity-20" />
                    <p className="text-sm italic">No history yet. Start spinning!</p>
                  </div>
                ) : (
                  history.map((item) => (
                    <div key={item.id} className="group relative bg-zinc-50 rounded-2xl p-4 border border-zinc-100 hover:border-emerald-200 transition-colors">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                          {item.mode}
                        </span>
                        <span className="text-[10px] text-zinc-400">
                          {new Date(item.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-xs text-zinc-500 line-clamp-2 mb-2 italic">"{item.original}"</p>
                      <p className="text-sm text-zinc-700 line-clamp-3 leading-relaxed">{item.rewritten}</p>
                      <button 
                        onClick={() => {
                          setInputText(item.original);
                          setOutputText(item.rewritten);
                          setShowHistory(false);
                        }}
                        className="mt-3 text-xs font-bold text-emerald-600 hover:underline flex items-center gap-1"
                      >
                        Restore <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  ))
                )}
              </div>
              {history.length > 0 && (
                <div className="p-6 border-t border-zinc-100">
                  <button 
                    onClick={() => {
                      if (confirm('Clear all history?')) {
                        setHistory([]);
                        localStorage.removeItem('spinbot_history');
                      }
                    }}
                    className="w-full py-3 text-sm font-bold text-red-500 hover:bg-red-50 rounded-xl transition-colors"
                  >
                    Clear History
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <div className="min-h-screen bg-[#F9FAFB] text-zinc-900 font-sans selection:bg-emerald-100 selection:text-emerald-900 flex flex-col">
        <div className="flex-1">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </div>

        {/* Footer */}
        <footer className="mt-24 border-t border-zinc-200 bg-white py-12">
          <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-8">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-6 h-6 bg-zinc-900 rounded flex items-center justify-center">
                <RefreshCw className="text-white w-3.5 h-3.5" />
              </div>
              <span className="font-bold text-zinc-900">SpinBot AI</span>
            </Link>
            <div className="flex gap-8 text-sm text-zinc-400">
              <Link to="/privacy" className="hover:text-zinc-900 transition-colors">Privacy Policy</Link>
              <Link to="/terms" className="hover:text-zinc-900 transition-colors">Terms of Service</Link>
              <Link to="/contact" className="hover:text-zinc-900 transition-colors">Contact</Link>
            </div>
            <p className="text-sm text-zinc-400">© 2026 SpinBot AI. All rights reserved.</p>
          </div>
        </footer>
      </div>
    </BrowserRouter>
  );
}
